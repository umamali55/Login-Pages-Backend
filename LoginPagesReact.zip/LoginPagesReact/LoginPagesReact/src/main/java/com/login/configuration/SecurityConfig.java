package com.login.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.login.service.UserService;

//SecurityConfig.java
@Configuration
@EnableWebMvc
public class SecurityConfig extends WebSecurityConfigurerAdapter {
 @Autowired
 private UserService userService;

 @Override
 protected void configure(HttpSecurity http) throws Exception {
     http
         .authorizeRequests()
             .antMatchers("/api/login").permitAll()
             .anyRequest().