package com.login.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.login.model.User;
import com.login.repository.UserRepository;
import com.login.service.UserService;



@CrossOrigin(origins="http://localhost:3000/")
@RestController
@RequestMapping("/api")
public class UserController {
 @Autowired
 private UserService userService;

 @PostMapping
 public User createUser(@RequestBody User user) {
     return userService.save(user);
 }
}

/*public class RegistrationController {

 @Autowired
 private UserRepository userRepository;

 @PostMapping("/register")
 public String registerUser(@RequestBody User user) {
     userRepository.save(user);   
     return "User registered successfully!";
 }

 @PostMapping("/login")
 public String loginUser(@RequestBody User user) {
     User existingUser = userRepository.findByUsername(user.getUserName());   
     if (existingUser != null && existingUser.getPassword().equals(user.getPassword())) {
         return "Login successful!";
     } else {
         return "Invalid username or password!";
     }
 }
}
*/